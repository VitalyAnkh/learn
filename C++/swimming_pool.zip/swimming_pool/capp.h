//
// Created by vitalyr on 19-5-25.
//

#ifndef SWIMMING_POOL_CAPP_H
#define SWIMMING_POOL_CAPP_H

#include <iostream>
using namespace std;

class CApp {
public:
    int initialize();

};


#endif //SWIMMING_POOL_CAPP_H
