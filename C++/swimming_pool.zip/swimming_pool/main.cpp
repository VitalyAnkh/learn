#include"capp.h"
CApp theApp;
int main(){
    theApp.initialize();
    return 0;
}