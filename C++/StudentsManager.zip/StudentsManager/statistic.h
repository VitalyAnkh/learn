#pragma once

void statistic1();

void statistic2();

void statistic3();

void statistic4();